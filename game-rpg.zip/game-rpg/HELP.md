# Getting Started

### For running the application use the below command.

java -jar target/game-rpg-1.0.jar



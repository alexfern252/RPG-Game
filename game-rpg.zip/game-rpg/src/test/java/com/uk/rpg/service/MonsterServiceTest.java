package com.uk.rpg.service;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

/**
 * @author Alexandre Fernandes
 */
@TestInstance(Lifecycle.PER_CLASS)
public class MonsterServiceTest {

	MonsterService service;

	@BeforeAll
	public void startUp() {
		service = new MonsterService();
	}

	@Test
	public void testGetFinalMonster_isFinal() {
		Assertions.assertTrue(service.getFinalMonster().isFinalMonster());
	}
}

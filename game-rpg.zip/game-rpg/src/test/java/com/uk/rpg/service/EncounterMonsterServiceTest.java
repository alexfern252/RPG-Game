package com.uk.rpg.service;

import static org.mockito.Mockito.never;
import static org.mockito.Mockito.when;

import java.util.Random;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.mockito.Mockito;

import com.uk.rpg.domain.Warrior;
import com.uk.rpg.domain.Monster;

/**
 * @author Alexandre Fernandes
 */
@TestInstance(Lifecycle.PER_CLASS)
public class EncounterMonsterServiceTest {
    private MonsterService monsterService;
    private Random random;

    @BeforeAll
    public void startUp() {
        random = Mockito.mock(Random.class);
        monsterService = Mockito.mock(MonsterService.class);
    }

    @Test
    public void testTryToFindAMonster_noMonsterFound() {
        int probability = 40;
        EncounterMonsterService service = new EncounterMonsterService(monsterService, random, probability);
        Mockito.verify(monsterService, never()).createRandomMonster(probability);
        when(random.nextInt(100)).thenReturn(probability);
        service.tryToFindAMonster(new Warrior("", 0, 0));
    }

    @Test
    public void testTryToFindAMonster_monsterFound() {
        int probability = 40;
        Monster expected = new Monster("test", 0, 0, 0, false);
        EncounterMonsterService service = new EncounterMonsterService(monsterService, random, probability);
        when(random.nextInt(100)).thenReturn(probability - 1);
        when(monsterService.createRandomMonster(probability - 1)).thenReturn(expected);
        Monster monster = service.tryToFindAMonster(new Warrior("", 0, 0));
        Assertions.assertEquals(expected, monster);
    }
}

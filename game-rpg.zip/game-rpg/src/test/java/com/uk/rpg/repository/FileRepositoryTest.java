package com.uk.rpg.repository;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.uk.rpg.domain.Warrior;
import com.uk.rpg.domain.WarriorState;
import com.uk.rpg.repository.impl.WarriorRepositoryImpl;

/**
 * @author Alexandre Fernandes
 */
public class FileRepositoryTest {

    @Test
    public void test_saveAndLoad() throws IOException {
        String fileName = "file.dat";
        String folder = "folder";
        
        WarriorRepositoryImpl repository =  new WarriorRepositoryImpl(folder, fileName);
        WarriorState expectedState = new WarriorState("name", 101, 3, 20, 60, 5);
        repository.save(new Warrior(expectedState));
        Warrior loadedHero = repository.load();
        Assertions.assertEquals(expectedState, loadedHero.getCurrentState());

        // cleanup
        Path directory = Paths.get(folder);
        for (Path file : Files.newDirectoryStream(directory)) {
            Files.delete(file);
        }
        Files.delete(directory);
    }
}

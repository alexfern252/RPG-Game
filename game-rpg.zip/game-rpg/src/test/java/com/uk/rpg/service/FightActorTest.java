package com.uk.rpg.service;



import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

import com.uk.rpg.domain.Warrior;
import com.uk.rpg.projection.FightActor;
import com.uk.rpg.domain.Monster;

/**
 * @author Alexandre Fernandes
 */
@TestInstance(Lifecycle.PER_CLASS)
public class FightActorTest {
    FightActor service = new FightActor();

    @BeforeAll
    public void startUp() {
        service = new FightActor();
    }

    @Test
    public void testPerform_heroNotSufferDamageWhenKillMonsterAtFirstHit() {
        int heroDamage = 10;
        int monsterHealth = 10;
        int heroHealth = 1;
        Warrior warrior = new Warrior("", heroHealth, heroDamage);
        Monster monster = new Monster("", monsterHealth, 100, 0, false);
        service.perform(warrior, monster);
        Assertions.assertEquals(heroHealth, warrior.getHealthPoints());
        Assertions.assertFalse(monster.isAlive());
    }

    @Test
    public void testPerform_monsterDoNotHitBackWhenKilled() {
        Warrior warrior = new Warrior("", 10, 5);
        Monster monster = new Monster("", 25, 2, 0, false);
        service.perform(warrior, monster);
        assertEquals(2, warrior.getHealthPoints());
        Assertions.assertFalse(monster.isAlive());
    }

    @Test
    public void testPerform_heroNotHittingAfterMonsterKillHim() {
        Warrior warrior = new Warrior("", 10, 5);
        Monster monster = new Monster("", 6, 10, 0, false);
        service.perform(warrior, monster);
        Assertions.assertFalse(warrior.isAlive());
        assertEquals(1, monster.getHealthPoints());
        Assertions.assertTrue(monster.isAlive());
    }
}

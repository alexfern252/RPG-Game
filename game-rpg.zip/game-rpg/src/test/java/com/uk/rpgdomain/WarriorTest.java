package com.uk.rpgdomain;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.uk.rpg.domain.Warrior;

/**
 * @author A.Buyanov 14.05.2017.
 */
public class WarriorTest {
    @Test
    public void testGainExperiencePoints_pointsAdded() {
        Warrior warrior = new Warrior("", 1, 1);
        Assertions.assertEquals(0, warrior.getExperiencePoints());
        warrior.gainExperiencePoints(20);
        Assertions.assertEquals(20, warrior.getExperiencePoints());
    }

    @Test
    public void testGainExperiencePoints_levelIncreased() {
        Warrior warrior = new Warrior("", 1, 1);
        Assertions.assertEquals(0, warrior.getLevel());
        warrior.gainExperiencePoints(Warrior.EXPERIENCE_POINTS_PER_LEVEL );
        Assertions.assertEquals(1, warrior.getLevel());
    }

    @Test
    public void testGainExperiencePoints_healthRestoredAfterLevelUp() {
        Warrior warrior = new Warrior("", 10, 1);
        warrior.causeDamage(4);
        Assertions.assertEquals(6, warrior.getHealthPoints());
        warrior.gainExperiencePoints(Warrior.EXPERIENCE_POINTS_PER_LEVEL );
        Assertions.assertEquals(20, warrior.getHealthPoints());
    }

    @Test
    public void testCauseDamage_overflow() {
        Warrior warrior = new Warrior("", 10, 1);
        warrior.causeDamage(1000);
        Assertions.assertEquals(0, warrior.getHealthPoints());
    }

    @Test
    public void testCauseDamage_negativeDamage() {
        Warrior warrior = new Warrior("", 10, 1);
        warrior.causeDamage(-1);
        Assertions.assertEquals(10, warrior.getHealthPoints());
    }

    @Test
    public void testCauseDamage_dead() {
        Warrior warrior = new Warrior("", 10, 1);
        warrior.causeDamage(10);
        Assertions. assertFalse(warrior.isAlive());
    }
}

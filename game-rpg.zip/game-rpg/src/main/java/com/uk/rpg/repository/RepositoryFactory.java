package com.uk.rpg.repository;

import com.uk.rpg.repository.impl.WarriorRepositoryImpl;

/**
 * @author Alexandre Fernandes
 */
public class RepositoryFactory {
	private static final String FOLDER_NAME = "data";
	private static final String FILE_NAME = "save.dat";

	public WarriorRepository createRepository() {
		return new WarriorRepositoryImpl(FOLDER_NAME, FILE_NAME);
	}
}

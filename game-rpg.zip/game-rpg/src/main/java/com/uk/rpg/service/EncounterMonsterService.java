package com.uk.rpg.service;

import java.util.Random;

import com.uk.rpg.domain.Warrior;
import com.uk.rpg.domain.Monster;

/**
/**
 * @author Alexandre Fernandes
 */
public class EncounterMonsterService {
    private final MonsterService monsterService;
    private final Random random;
    private final int chanceToEncounterMonster;

    public EncounterMonsterService(MonsterService monsterService, Random random, int chanceToEncounterMonster) {
        this.monsterService = monsterService;
        this.random = random;
        this.chanceToEncounterMonster = chanceToEncounterMonster;
    }

    public Monster tryToFindAMonster(Warrior warrior) {
        int rnd = random.nextInt(100);
        if (rnd < chanceToEncounterMonster) {
            return monsterService.createRandomMonster(random.nextInt(100) + warrior.getLevel());
        }
        return null;
    }
}

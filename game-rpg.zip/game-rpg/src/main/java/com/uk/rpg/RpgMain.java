package com.uk.rpg;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.Random;

import com.uk.rpg.domain.Monster;
import com.uk.rpg.domain.Warrior;
import com.uk.rpg.projection.ActionParser;
import com.uk.rpg.projection.FightActor;
import com.uk.rpg.projection.UserAction;
import com.uk.rpg.projection.UserInteraction;
import com.uk.rpg.repository.RepositoryFactory;
import com.uk.rpg.repository.WarriorRepository;
import com.uk.rpg.service.EncounterMonsterService;
import com.uk.rpg.service.FightService;
import com.uk.rpg.service.MonsterService;
import com.uk.rpg.service.SystemService;
import com.uk.rpg.service.WarriorService;

/**
 * @author Alexandre Fernandes
 */
public class RpgMain {
	private static boolean runLoop = true;

	public static Properties prop = null;

	public static void main(String[] args) {
		initializePropertiesValues();
		MonsterService monsterService = new MonsterService();
		EncounterMonsterService encounterMonsterService = new EncounterMonsterService(monsterService, new Random(), 50);
		UserInteraction userInteraction = new UserInteraction(new SystemService(), new ActionParser());
		WarriorRepository warriorRepository = new RepositoryFactory().createRepository();
		WarriorService warriorService = new WarriorService(warriorRepository);
		FightService fightService = new FightService(new FightActor(), userInteraction);

		UserAction initialAction = userInteraction.splashScreen(monsterService.getFinalMonster());
		final Warrior warrior;
		switch (initialAction) {
		case NEW:
			String name = userInteraction.readWarriorName();
			warrior = warriorService.create(name);
			break;
		case LOAD:
			warrior = warriorService.load();
			break;
		default:
			warrior = warriorService.create("NoNameWarrior");
		}

		userInteraction.warriorStats(warrior);

		Monster monster = null;
		while (runLoop) {
			UserAction mainAction = userInteraction.getMainAction(monster);
			switch (mainAction) {
			case QUIT:
				userInteraction.quitGame();
				break;
			case SAVE:
				warriorRepository.save(warrior);
				userInteraction.saveGame();
				break;
			case EXPLORE:
				if (monster == null) {
					monster = encounterMonsterService.tryToFindAMonster(warrior);
				}
				userInteraction.encounterMonster(monster);
				break;
			case RUN:
				userInteraction.runFromMonster(monster);
				monster = null;
				break;
			case FIGHT:
				monster = fightService.performFight(warrior, monster);
				break;
			case INFO:
				userInteraction.warriorStats(warrior);
				if (monster != null) {
					userInteraction.monsterInfo(monster);
				}
				break;
			default:
				userInteraction.noAction();
				break;
			}
		}
	}

	private static void initializePropertiesValues() {
		try (InputStream input = RpgMain.class.getClassLoader().getResourceAsStream("application.properties")) {

			prop = new Properties();
			if (input == null) {
				System.out.println("Sorry, unable to find properties file");
				return;
			}

			// load a properties file from class path, inside static method
			prop.load(input);

		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
}

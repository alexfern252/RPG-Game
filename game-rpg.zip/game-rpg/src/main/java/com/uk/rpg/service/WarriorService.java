package com.uk.rpg.service;

import com.uk.rpg.domain.Warrior;
import com.uk.rpg.repository.WarriorRepository;

/**
 * @author Alexandre Fernandes
 */
public class WarriorService {
    private final WarriorRepository repository;

    public WarriorService(WarriorRepository repository) {
        this.repository = repository;
    }

    public Warrior create(String name) {
        return new Warrior(name, 20, 5);
    }

    public Warrior load() {
        return repository.load();
    }
}

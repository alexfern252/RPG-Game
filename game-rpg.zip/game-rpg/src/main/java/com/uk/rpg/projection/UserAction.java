package com.uk.rpg.projection;

import java.util.stream.Stream;

/**
 * @author Alexandre Fernandes
 */
public enum UserAction {
    NEW("N"),
    LOAD("L"),
    SAVE("S"),
    QUIT("Q"),
    EXPLORE("E"),
    FIGHT("F"),
    RUN("R"),
    INFO("I"),
    NO_ACTION("");

    private String command;

    UserAction(String command) {
        this.command = command;
    }

    public static UserAction getActionByCommand(String command) {
        return Stream.of(values()).filter(a -> a.command.equalsIgnoreCase(command)).findFirst().orElse(getDefault());
    }

    public static UserAction getDefault() {
        return NO_ACTION;
    }
}

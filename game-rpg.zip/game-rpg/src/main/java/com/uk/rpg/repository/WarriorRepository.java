package com.uk.rpg.repository;

import com.uk.rpg.domain.Warrior;

/**
 * @author Alexandre Fernandes
 */
public interface WarriorRepository {
	void save(Warrior warrior);

	Warrior load();
}

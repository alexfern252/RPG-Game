package com.uk.rpg.projection;

import com.uk.rpg.domain.Warrior;
import com.uk.rpg.domain.WarriorState;
import com.uk.rpg.RpgMain;
import com.uk.rpg.domain.Monster;
import com.uk.rpg.service.SystemService;

/**
 * @author Alexandre Fernandes
 */
public class UserInteraction {
    private final SystemService system;
    private final ActionParser actionParser;

    public UserInteraction(SystemService system, ActionParser actionParser) {
        this.system = system;
        this.actionParser = actionParser;
    }

    public UserAction splashScreen(Monster finalMoster) {
    	system.printf(RpgMain.prop.getProperty("welcome.message"), finalMoster.getName());
    	system.printf(RpgMain.prop.getProperty("user.action.select"));
        return actionParser.parse(system.read());
    }

    public String readWarriorName() { 
        System.out.println(RpgMain.prop.getProperty("warrior.name"));
        return system.read();
    }

    public void warriorStats(Warrior warrior) {
        system.printf(RpgMain.prop.getProperty("warrior.stats"), warrior.getName(), warrior.getLevel(), warrior.getExperiencePoints());
        system.printf(RpgMain.prop.getProperty("warrior.stats.info"),
                warrior.getDamagePoints(), warrior.getHealthPoints(), warrior.getMaximumHealthPoints());
    }

    public void monsterInfo(Monster monster) {
        system.printf(RpgMain.prop.getProperty("monster.info"),
                monster.getName(), monster.getDamagePoints(), monster.getHealthPoints(), monster.getExperiencePointsReward());
        if (monster.isFinalMonster()) {
            system.println(RpgMain.prop.getProperty("monster.final"));
        }
    }

    public UserAction getMainAction(Monster monster) {
        if (monster != null) {
            System.out.printf(RpgMain.prop.getProperty("user.action.next"), monster.getName());
        }
        else {
            System.out.println(RpgMain.prop.getProperty("user.action.save"));
        }
        return actionParser.parse(system.read());
    }

    public void endOfFight(WarriorState beforeFight, WarriorState afterFight, WarriorState afterExperience, Monster monster) {
        if (afterFight.isAlive()) {
            system.printf(RpgMain.prop.getProperty("monster.killed"), monster.getName());
            system.printf(RpgMain.prop.getProperty("warrior.fight.info"),
                    monster.getInitialHealthPoints(), beforeFight.healthPoints - afterFight.healthPoints, afterFight.healthPoints);

            system.printf(RpgMain.prop.getProperty("warrior.fight.points"), afterExperience.experiencePoints - beforeFight.experiencePoints);
            if (afterExperience.level > beforeFight.level) {
                system.printf(RpgMain.prop.getProperty("warrior.level.next"), afterExperience.level);
            }
            if (monster.isFinalMonster()) {
                system.exit(RpgMain.prop.getProperty("warrior.game.over"));
            }
        } else {
            system.exit(RpgMain.prop.getProperty("warrior.game.killed"));
        }
    }

    public void encounterMonster(Monster monster) {
        if (monster == null) {
            system.println(RpgMain.prop.getProperty("warrior.explore.nothing"));
        }
        else {
            system.printf(RpgMain.prop.getProperty("warrior.encounter"), monster.getName());
        }
    }

    public void runFromMonster(Monster monster) {
        if (monster != null) {
            system.printf(RpgMain.prop.getProperty("game.warrior.run"), monster.getName());
        }
    }

    public void quitGame() {
        system.exit(RpgMain.prop.getProperty("game.quit"));
    }

    public void saveGame() {
        system.println(RpgMain.prop.getProperty("game.save"));
    }

    public void noAction() {
        system.println(RpgMain.prop.getProperty("game.noaction"));
    }
}

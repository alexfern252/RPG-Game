package com.uk.rpg.repository.impl;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.uk.rpg.domain.Warrior;
import com.uk.rpg.domain.WarriorState;
import com.uk.rpg.repository.WarriorRepository;

/**
 * @author Alexandre Fernandes
 */
public class WarriorRepositoryImpl implements WarriorRepository {
	private final String folderName;
	private final String fileName;

	public WarriorRepositoryImpl(String folderName, String fileName) {
		this.folderName = folderName;
		this.fileName = fileName;
	}

	@Override
	public void save(Warrior warrior) {
		File dir = new File(folderName);
		if (!dir.exists()) {
			dir.mkdir();
		}
		try (FileOutputStream fileOutputStream = new FileOutputStream(getFullPath());
				ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream)) {
			objectOutputStream.writeObject(warrior.getCurrentState());
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public Warrior load() {
		try (FileInputStream fileInputStream = new FileInputStream(getFullPath());
				BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream);
				ObjectInput objectInputStream = new ObjectInputStream(bufferedInputStream)) {
			WarriorState warriorState = (WarriorState) objectInputStream.readObject();
			return new Warrior(warriorState);
		} catch (IOException | ClassNotFoundException e) {
			throw new RuntimeException(e);
		}
	}

	private String getFullPath() {
		return String.format("%s%s%s", folderName, File.separator, fileName);
	}
}

package com.uk.rpg.service;

import com.uk.rpg.domain.Warrior;
import com.uk.rpg.domain.WarriorState;
import com.uk.rpg.domain.Monster;
import com.uk.rpg.projection.FightActor;
import com.uk.rpg.projection.UserInteraction;

/**
 * @author Alexandre Fernandes
 */
public class FightService {
    private final FightActor actor;
    private final UserInteraction userInteraction;

    public FightService(FightActor actor, UserInteraction userInteraction) {
        this.actor = actor;
        this.userInteraction = userInteraction;
    }

    public Monster performFight(Warrior warrior, Monster monster) {
        if (monster == null)
            return null;
        WarriorState beforeFight = warrior.getCurrentState();
        actor.perform(warrior, monster);
        WarriorState afterFight = warrior.getCurrentState();
        if (warrior.isAlive()) {
            warrior.gainExperiencePoints(monster.getExperiencePointsReward());
        }
        WarriorState afterExperience = warrior.getCurrentState();
        userInteraction.endOfFight(beforeFight, afterFight, afterExperience, monster);
        if (monster.isAlive())
            return monster;
        return null;
    }
}

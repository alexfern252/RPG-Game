package com.uk.rpg.projection;

import com.uk.rpg.domain.Warrior;
import com.uk.rpg.domain.Monster;

/**
 * @author Alexandre Fernandes
 */
public class FightActor {
    public void perform(Warrior warrior, Monster monster) {
        while (monster.isAlive() && warrior.isAlive()) {
            monster.causeDamage(warrior.getDamagePoints());
            if (monster.isAlive()) {
                warrior.causeDamage(monster.getDamagePoints());
            }
        }
    }
}

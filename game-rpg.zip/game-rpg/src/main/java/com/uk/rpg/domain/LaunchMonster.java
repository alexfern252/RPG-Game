package com.uk.rpg.domain;

/**
 * @author Alexandre Fernandes
 */
public class LaunchMonster {
    protected final String name;
    protected final int damagePoints;
    protected final int experiencePointsReward;
    protected final boolean finalMonster;
    protected int healthPoints;

    public LaunchMonster(String name, int damagePoints, int experiencePointsReward, boolean finalMonster, int healthPoints) {
        this.name = name;
        this.damagePoints = damagePoints;
        this.experiencePointsReward = experiencePointsReward;
        this.finalMonster = finalMonster;
        this.healthPoints = healthPoints;
    }

    public Monster createNew() {
        return new Monster(name, healthPoints, damagePoints, experiencePointsReward, finalMonster);
    }


}

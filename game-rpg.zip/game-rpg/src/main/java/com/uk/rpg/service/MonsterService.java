package com.uk.rpg.service;

import com.uk.rpg.domain.Monster;
import com.uk.rpg.domain.LaunchMonster;

/**
 * @author Alexandre Fernandes
 */
public class MonsterService {
    private final LaunchMonster REFERENCE_RAT = new LaunchMonster("Rat", 2, 2, false, 5);
    private final LaunchMonster REFERENCE_GOBLIN = new LaunchMonster("Goblin", 3, 10, false, 10);
    private final LaunchMonster REFERENCE_ORC = new LaunchMonster("Orc", 5, 20, false, 15);
    private final LaunchMonster REFERENCE_TROLL = new LaunchMonster("Troll", 9, 35, false, 25);
    private final LaunchMonster REFERENCE_BARLOG = new LaunchMonster("Barlog", 20, 1000, true, 100);


    public Monster getFinalMonster() {
        return REFERENCE_BARLOG.createNew();
    }

    public Monster createRandomMonster(int percentage) {
        if (percentage < 15) {
            return REFERENCE_RAT.createNew();
        }
        if (percentage < 45) {
            return REFERENCE_GOBLIN.createNew();
        }
        if (percentage < 85) {
            return REFERENCE_ORC.createNew();
        }
        if (percentage < 99) {
            return REFERENCE_TROLL.createNew();
        }
        return REFERENCE_BARLOG.createNew();
    }
}

package com.uk.rpg.service;

import java.util.Scanner;

/**
 * @author Alexandre Fernandes
 */
public class SystemService {
    private final Scanner scanner = new Scanner(System.in);


    public void exit(String message) {
        System.out.println(message);
        System.exit(0);
    }

    public void printf(String format, Object ... args) {
        System.out.printf(format, args);
    }

    public void println(String message) {
        System.out.println(message);
    }

    public String read() {
        return scanner.next();
    }
}

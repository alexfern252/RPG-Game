package com.uk.rpg.projection;

/**
 * @author Alexandre Fernandes
 */
public class ActionParser {
    public UserAction parse(final String s) {
        return UserAction.getActionByCommand(s.toUpperCase());
    }
}
